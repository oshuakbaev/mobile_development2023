package com.example.applfive;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
