import 'package:flutter/material.dart';
import 'dart:math' as math;
void main(){
  runApp(MyApp());
}


class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title:"FirstProject",
      theme: ThemeData(scaffoldBackgroundColor: Colors.green),
      home: Scaffold(

        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            // children: [
            //   Text("OP is real"),
            //   Text("OP is real"),
            //   Text("OP is real"),
            // ],
            children:<Widget>[
              Container(
                color: Colors.blue,
                height: 100,
                width: 100,
                  child:Padding(
                    padding: EdgeInsets.all(12.0),
                    child: Text("It's padding"),
                  ),
              ),
              const Divider(
                height: 20,
                thickness: 5,
                indent: 20,
                endIndent: 20,
                color: Colors.black,
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.all(12.0),
                  child:Container(
                  color:Colors.amber,
                  width:100,
                 ),
                ),
              ),
              const Divider(
                height: 20,
                thickness: 5,
                indent: 20,
                endIndent: 20,
                color: Colors.black,
              ),
              Container(
                color: Colors.blue,
                height: 100,
                width: 100,
                  child:Padding(
                    padding: EdgeInsets.all(20.0),
                    child: Text("It's padding"),
                  ),
              ),
              Container(
                color:Colors.black,
                child:Transform(
                    alignment: Alignment.topRight,
                    transform: Matrix4.skewY(0.3)..rotateZ(-math.pi/12.0),
                    child: Container(
                      padding: const EdgeInsets.all(12.0),
                      color: const Color(0xFFE8581C),
                      child: const Text("Transform"),
                    ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}