package com.example.lab2_2_ad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
